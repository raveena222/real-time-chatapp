import { createContext } from "react";
const chatContext = createContext();
export default chatContext;
